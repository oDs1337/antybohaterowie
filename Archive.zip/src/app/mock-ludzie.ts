import { Czlowiek } from './czlowiek';
export const LUDZIE:Czlowiek[]=[{
  id: 1,
  nazwisko: 'Grey',
  imie: 'Sasha',
  wiek: 33,
  umiejetnosci: 'Wielka kobieta',
  opis: 'Sasha Grey, własc. Marina Ann Hantzis – amerykańska aktorka, modelka, muzyk, pisarka, wcześniej aktorka pornograficzna.',
  zdjecie: 'sasha.jpeg',
  },
  {
    id: 2,
    nazwisko: 'Twoja',
    imie: 'Stara',
    wiek: 17,
    umiejetnosci: 'Wielka kobieta',
    opis: 'Sasha Grey, własc. Marina Ann Hantzis – amerykańska aktorka, modelka, muzyk, pisarka, wcześniej aktorka pornograficzna.',
    zdjecie: 'sasha.jpeg',
  },
  {
    id: 3,
    nazwisko: 'Moja',
    imie: 'Stara',
    wiek: 40,
    umiejetnosci: 'Wielka kobieta',
    opis: 'Sasha Grey, własc. Marina Ann Hantzis – amerykańska aktorka, modelka, muzyk, pisarka, wcześniej aktorka pornograficzna.',
    zdjecie: 'sasha.jpeg',
  },

];

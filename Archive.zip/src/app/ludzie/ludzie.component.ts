import { LUDZIE } from './../mock-ludzie';
import { Czlowiek } from './../czlowiek';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ludzie',
  templateUrl: './ludzie.component.html',
  styleUrls: ['./ludzie.component.scss']
})
export class LudzieComponent implements OnInit {
  ludzie = LUDZIE;
  constructor() { }

  ngOnInit(): void {
  }

}

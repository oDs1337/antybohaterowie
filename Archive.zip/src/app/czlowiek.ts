export interface Czlowiek{
  id: number;
  nazwisko: string;
  imie: string;
  wiek: number;
  umiejetnosci: string;
  opis: string;
  zdjecie: string;
}

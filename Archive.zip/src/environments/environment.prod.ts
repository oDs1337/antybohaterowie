export const environment = {
  production: true,

  firebaseConfig: {
    apiKey: 'No Web API Key for this project',
    authDomain: '',
    databaseURL: '',
    storageBucket: '',
    messagingSenderId: '',
    projectId: 'project-115446287218'
  },
};
